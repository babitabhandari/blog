<?php require 'db1.php';
   $check = $_POST['check'];
  $oldval = $_POST['oldval']; 
 // $dynamic_text = $_POST['textbox2'];
  //echo $dynamic_text;
 // print_r($check);
  //print_r($oldval);
  
   //print_r($check);
  $table  = 'user';
 $column = $check;
 // $column1= $dynamic_text;
 //old value database me old custom field se save kr ra hai 


 foreach($check as $col){
 $add = "ALTER TABLE $table ADD $col VARCHAR( 255 ) NOT NULL";
 mysqli_query($link,$add);
 }

   $store= $_POST['store'];
  
  //$tbl_fields = $check; 
   $tbl_fields= $oldval;
//print_r($tbl_fields);
 

  $handle = fopen("D:/babita/wamp/www/sendgrid/uploads/".$store,"r"); 
   $check12 = fgetcsv($handle,1000,",",'"'); 
  
  //  print_r($check12);
   $tbl_fields1 = array_intersect($check12,$oldval);
  
  //print_r($tbl_fields1); 
 
$v=array_intersect($tbl_fields1,$check);
//print_r($v);
$v1= array_diff($check,$tbl_fields1);
//print_r($v1);
// print_r($v);
// print_r($v1);
$v2=array_merge($v,$v1);
//print_r($v2);
 $arr= array_keys($tbl_fields1);
//print_r($arr);
$array1=array();


//print "<table>\n";
while($csv_line = fgetcsv($handle,1024)) {
   // print '<tr>';
 // print '<td>';
    for ($i = 0, $j = count($csv_line); $i < $j; $i++) {
    if(in_array($i, $arr))
    {
  
        $array1[]= $csv_line[$i];
        
        
}
 
}

//print_r($array1);
$matstring=implode("','", $array1);
$matstring="'".$matstring."'";


// print_r($matstring);
// $f=implode(',', $check);
$f= implode(',', $v2);
  // if($tbl_fields1 == $f){
  $q="INSERT INTO `user` ($f) VALUES ($matstring)";
 // $q="INSERT INTO `details`(".mysql_real_escape_string(implode(',', $tbl_fields)).") VALUES ($matstring)";
     //echo $q;

  mysqli_query($link,$q);
   unset($array1);

//print "</td>\n";
    //print "</tr>\n";



}

if($q){
    echo  "data inserted";
  }

  
?>