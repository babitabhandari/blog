<?php

    if (($handle = fopen("D:/babita/wamp/www/sendgrid/uploads/details.csv", "r")) !== false) {
        
        $csv_fields = fgetcsv($handle,1000,",",'"'); 
        $num = count($csv_fields);
   $v=0;
   $c =0; 
   while($v<$num)
        {
     $handle = fopen("D:/babita/wamp/www/sendgrid/uploads/details.csv", "r");       
     //for removing headers
    fgetcsv($handle,1000,",");
 
    while (($data = fgetcsv($handle, 8000, ",")) !== FALSE &&$c!=3 ) {
    echo $data[$v] . "\n";
      
     echo "<br>";
     $c++;
}
     $v++;
     $c=0;
 }

     
   
 }
 






 ?>