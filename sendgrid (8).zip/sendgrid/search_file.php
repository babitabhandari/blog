<?php if(isset($_POST['search'])){

$output = "";
$gender ="";
$age="";
if(!empty($_POST['age'])) {
$age=$_POST['age'];
$var1=$age;
$var = explode("-", $var1);
$var2= $var[0]; // piece1
$var3= $var[1]; // piece2
}
if(!empty($_POST['gender'])) {
$gender=$_POST['gender'];
}
if($gender=="" && $age==""){
  echo "<div class='alert alert-danger'>please select age or gender</div>";
}
else{
if($gender=="" && $age!=""){
$qre=mysql_query("select * from detail  where age Between '$var2' AND '$var3'");
}
elseif($age=="" && $gender!=""){
$qre=mysql_query("select * from detail where gender='$gender'");
}
elseif($age!="" && $gender!=""){
$qre=mysql_query("select * from detail   where age Between '$var2' AND '$var3' && gender='$gender'");
}
$columns_total = mysql_num_fields($qre);
echo '<table class="table table-inverse" style="float:left;">
<tr><th>First Name</th><th>Last Name</th><th>Email</th>
<th>Gender</th><th>Age</th>';
echo '</tr>';
echo '<tr>';
while ($r = mysql_fetch_array($qre)) {
echo '<tr>';  
for ($i = 1; $i < $columns_total; $i++) {
echo '<td>'.$output =$r[$i].'</td>';
//$output .="\n";
 //echo '</br>';
}
echo '</tr>';
//$output .="\n";
}
}
echo '</tr>';
echo '</table>';
if($output!=""){
  echo $output;
echo '<script type="text/javascript">
 $("#export").css("display","block");
 </script>';
 exit();
}
else{
    echo "data not found";
}

}
?>