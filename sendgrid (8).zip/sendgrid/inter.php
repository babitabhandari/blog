<?php
$array1=array('customer_name','last_name','email','gender');

$array2=array('last_name','email','cname','gender');
$array3=array('customer_name','last_name','email','gender');

$array4=array('last_name','email','cname','gender');
if()
$v=array_intersect($array1,$array2);
$v1= array_diff($array2,$array1);
print_r($v);
print_r($v1);
$v2=array_merge($v,$v1);
print_r($v2);

?>
<?php
// $array1=array('fn','ln','age','gender');
// $array2=array('fn','age','ln','gender');
// print_r(array_replace($array2, array_intersect_key($array1, $array2)));

// $array3=array('customer_name','last_name','email','gender');
// $array4=array('last_name','email','cname','gender');
// print_r(array_replace($array4, array_intersect_key($array3, $array4)));

// $array5=array('last_name','email','gender','cname');
// $array6=array('customer_name','last_name','email','gender');
// print_r(array_replace($array6, array_intersect_key($array5, $array6)));
?>