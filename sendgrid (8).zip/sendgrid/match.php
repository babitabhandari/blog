<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>

<table>
<div>
    <tr>
       

        <td><input type="text" name="bookprice"class="bookprice" value="200"/></td>
         <td><input type="checkbox" name="book" class="book" value="Checkbox 1"/></td>
    </tr>
    </div>
    <tr>
    <td><input type="text" name="bookprice"class="bookprice" value="300"/></td>
        <td><input type="checkbox" name="book" class="book" value="Checkbox 2"/></td>

        
    </tr>
    <tr>
    <td><input type="text" name="bookprice"class="bookprice" value="400"/></td>
        <td><input type="checkbox" name="book" class="book" value="Checkbox 3"/></td>

        
    </tr>
    <tr>
        <td><div><input type="submit" value="save" id="sub"></div></td>
    </tr>

</table>
<script>
$('#sub').click(function(){
    var bookidArr = [];
    var bookpriceArr = [];
    $('.book').each(function() {
        if ($(this).is(':checked')) {
                var current = $(this).val();
               bookpriceArr.push($(this).parents("tr").find(".bookprice").val())
               }
    bookidArr.push($(this).val());
    });
    alert(bookpriceArr);
});

</script>