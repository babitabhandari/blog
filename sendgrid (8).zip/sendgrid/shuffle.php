<?php 
$array1= array('red','green','yellow');
$array2= array('yellow','red','green');
$v= array();
$v=array_replace(array_flip($array2),$array1);
print_r($v);
?>