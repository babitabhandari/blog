<?php

    if (($handle = fopen("D:/babita/wamp/www/sendgrid/uploads/details.csv", "r")) !== false) {
        
        $csv_fields = fgetcsv($handle,1000,",",'"'); 
        $num = count($csv_fields);
        $num1 = count($handle);
        //echo $num1;
        
        //echo $num;
        //s$num = 1;
        $v=0;
        $flag = true;
$count=0;

$c =0; 
//print 3 line
// if($handle)
// { 
//     while(!feof($handle) && $c!=3)
//   {
//   $content = fgets($handle); 
//   if($content)
//   {

//  echo $content."<br>"; 
//     $c++;

//   }
//  }
// }


      





if($handle)
{ 
   
    while(!feof($handle) && $c!=3)
  {
  $content = fgets($handle); 
  if($content)
  {

 echo $content."<br>"; 
    $c++;
  
  }
 
 }

}

die();
$row=1;

        while($v<$num)
        {
            
    $handle = fopen("D:/babita/wamp/www/sendgrid/uploads/details.csv", "r");
    //for removing headers
    fgetcsv($handle,1000,",");
    while (($data = fgetcsv($handle, 8000, ",")) !== FALSE) {
    
       //if($flag) {  $flag = false; continue; }

   // echo $v;
        echo $data[$v] . "\n";
         
     
     echo "<br>";

     }

     $v++;
   
 }
      

}

?>