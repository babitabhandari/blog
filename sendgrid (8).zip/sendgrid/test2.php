<?php
$array1 = array("F_N", 'LN', 'AGE', 'USEREMAIL');
$array2 = array('FN', 'LN', 'userAGE');

// $w1= implode(' ', $array1)
 $words1 =  array_unique($array1);
 

$words2 =  array_unique($array2);
$intersection = array_intersect($words1, $words2);


if(count($array1)<=count($array2))
$intersection1 = array_diff($words2, $words1);
else
$intersection1 = array_diff($words1, $words2);
// 1 me hai pr two me nhi h 	

//print_r($intersection1);

if(count($intersection))
{
 foreach($intersection1 as $arr)
{
   // echo $arr;
	echo "<select>
	<option  value=''>New text field</option>
	</select>";

    echo '<input type="text" value="'.$arr.'">';
}  
foreach($intersection as $a)
{
    // echo $a;
	echo "<select>
	<option  value='".$a."'>$a</option>
	</select>";
    




}
}
?>