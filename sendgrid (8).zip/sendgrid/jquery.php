<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>

<script>
 jQuery(function($){                      
   $("select[name='drop']").change(function(){        
      var select = $(this);              
      if(select.val() == "text" || select.val() == "number"){     
          $("<input>").attr({type: "text", name: "text"}).appendTo(select.parent()); 
           $("#txt").remove();
          // $('.drop option[value!="text"]').remove(); 
       
       

      }
      else{
      //   if(select.val() == "number"){
      //   $("<input>").attr({type: "number", name: "text1"}).appendTo(select.parent()); 
      //   $("#txt").remove();
      //   $("<input>").attr({type: "text", name: "text"}).remove(select.parent()); 

      // }
    }
   });        
});
 

 </script>
</head>
<body>
	<?php  
	for($i=0;$i<5;$i++){	
	echo 	'<select name="drop" class="drop">

  <optgroup label="textfields" class="f">
    <option value="text" id="t" >text</option>
    <option value="number" id="n" >number</option>
  </optgroup>
  <optgroup label="German Cars">
    <option value="mercedes">Mercedes</option>
    <option value="audi">Audi</option>
  </optgroup>
</select>
<input type="text" value="custom field" id="txt" >'; 
echo "<br>";
}
?>
</body>
</html>