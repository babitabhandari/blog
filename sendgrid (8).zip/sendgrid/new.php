<?php
for($i=0;$i<3;$i++)
{
  echo "
      <table><tr> 
         
    <td><input type='text' value='heena' class='textbox1'></td>

<td><input type='checkbox' class='check1' name='check1'  value='100'></td></tr></table>"; 

}
?>
<input type="submit" id="submit"/>
<!DOCTYPE html>
<html lang="en">
<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
  <script>

 $(document).ready(function(){
 $('#submit').click(function(){
    
    var textbox1 = [];
    var check1 = [];
    $('.check1').each(function() {
        if ($(this).is(':checked')) {
                var current = $(this).val();
                // alert(current);
               textbox1.push($(this).parents("tr").find(".textbox1").val())
               }

   check1.push($(this).val());
   
    });
    alert(textbox1); 
    
  

return false;

     });

 });

</script>
</head>
<body>
      
</body>
</html>




foreach($intersection1 as $arr)
{
//   echo "<select name='drop' class='drop' style='width:200px;'>"; 
      
         
//            echo "<optgroup selected label='newtextfields'>
//          <option value='text'>text</option>
//          <option value='number'>number</option>
//          </optgroup>
//          <optgroup label='database headers'>"; 
        
//          $res = mysql_query('select * from detail');
// $numcolumn = mysql_num_fields($res);
// for ( $i = 1; $i < $numcolumn; $i++ ) {

//             $columnnames = mysql_field_name($res, $i);
//             echo '<option value="'.$columnnames.'">'.$columnnames.'</option>';
          
//           } 