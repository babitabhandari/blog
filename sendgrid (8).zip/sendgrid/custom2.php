<?php 

   require 'db.php';

 if(isset($_POST['upload'])){
if ($_FILES['csv']['size'] > 0) { 
  
   
$columnnames='';
$i=0;
$numcolumn='';
$show= '';
$numcolumn1='';
 $columnnames1='';
$j=0;

$file = $_FILES['csv']['tmp_name'];
$target_dir = "uploads/";
$target_file = $target_dir . basename($file);
// $target_file = $target_dir . basename($file);
$handle = fopen($file,"r"); 


$store=$_FILES["csv"]["name"];
 move_uploaded_file($file, "uploads/" . $store);
            //echo "Stored in: " . "uploads/" . $store . "<br />";
$csv_fields = fgetcsv($handle,1000,",",'"'); 

// $continue = true;
// while (($data = fgetcsv($handle, 1000, ",")) !== FALSE && $continue) {
//     // check for valid email (presuming it's in column 1)
//     $continue = filter_var($data[0], FILTER_VALIDATE_EMAIL);
// }

// $matcher = $_REQUEST['email'];

// while ($row = fgetcsv($handle, 1000, '#')) {
// if ( strtolower($row[0]) == strtolower($matcher) ) {
// echo "found";
// break;
// }
// else{
//  echo "not";
// }
// }
// fclose($fp);

//$tbl_fields = array('first_name','last_name','email');
//$tbl_fields = array('first_name','last_name','email');
$arr12=array();

$sql = "SHOW COLUMNS FROM user";
 $result = mysql_query($sql);

while($row = mysql_fetch_assoc($result)){
$arr12[]=$row['Field'];
}
//print_r($arr);
$tbl_fields=array_slice($arr12, 1);
$array1 = $csv_fields;
$array2 = $tbl_fields; 
//$c=implode(" ",$array1);
//print_r($c);
//print_r($array2);
$words1 =  array_unique($array1);
//print_r($words1)."<br>";

$words2 =  array_unique($array2);
//print_r($words2)."<br>";
$default=array();
$intersection = array_intersect($words1, $words2);
//$intersection3= sort($array1, $words2);
//print_r($intersection3);
// if(count($array1)<=count($array2)){
 $intersection1 = array_diff($words1, $words2);
// }
//  else{
// $intersection1 = array_diff($words1, $words2);

// }
$merge= array_merge($intersection, $intersection1);
//print_r($merge);
usort($merge, function($a, $b) use ($words1){
   // sort using the numeric index of the second array
   $valA = array_search($a, $words1);
   $valB = array_search($b, $words1);

   // move items that don't match to end
   if ($valA === false)
       return -1;
   if ($valB === false)
       return 0;

   if ($valA > $valB)
       return 1;
   if ($valA < $valB)
       return -1;
   return 0;
});
//print_r($merge);
$row = 1;
$f = $handle;


//$tbl_fields = array('first_name','last_name','email');
if ($handle !== FALSE) {

  //if($csv_fields !== FALSE) {
        echo '<div class="container panel" style="background:#F5F7FA;width:90%;margin-top:30px;">
        <div class="row" >
        <div class="col-md-6">
      
                <span class="glyphicon glyphicon-remove btn"></span>';
        
   echo "<div style='color:red;'>Please check the column headers below to confirm we've labeled them correctly.</div>";

// foreach($merge as $a)
// {

    foreach($merge as $a)
{
  if(in_array($a,$array2)){
  
    // if($columnnames == $a){
       echo "<div class='form-group'><table>"; 
     
echo "<tr><td>
<select name='drop' class='select_drop textbox textbox1 form-control' style='width:200px;'>"; 
          
         echo "<option  value='".$a."'>$a</option>";
       
         echo "<optgroup label='newtextfields' class='txtfields' >
         <option value='text' >text</option>
         <option value='number'>number</option>
         </optgroup>
         <optgroup label='database headers'>"; 
        
         $res = mysql_query('select * from user');
$numcolumn = mysql_num_fields($res);
for ( $i = 1; $i < $numcolumn; $i++ ) {
            $columnnames = mysql_field_name($res, $i);
            echo '<option value="'.$columnnames.'" class="d">'.$columnnames.'</option>';
               
   
          } 

         echo "</optgroup></td>";

echo "
<td><input  type='hidden' value='".$a."'  class='textbox2  form-control' id='textbox2'></td>
<td>
<input type='checkbox'  name='check' value='".$a."' class='check checkbox-primary' style='margin-left:5px;'>Add Column</td> 

<br>"; 

 echo "</select></tr></table></div>";
 }
  

else{
  echo "<div class='form-group'><select name='drop' class='drop form-control' >"; 
      
         
           echo "<optgroup selected label='newtextfields'>
         <option value='text'>text</option>
         <option value='number'>number</option>
         </optgroup>
         <optgroup label='database headers' class='hd'>"; 
        
         $res = mysql_query('select * from user');
$numcolumn = mysql_num_fields($res);
for ( $i = 1; $i < $numcolumn; $i++ ) {

            $columnnames = mysql_field_name($res, $i);
            echo '<option value="'.$columnnames.'">'.$columnnames.'</option>';
          
          } 
         echo "</optgroup>";
     echo "</select></div>";
     
    
     echo "<table style='margin-top:4px;'>
      <tr style='margin-left:10px;display:inline;margin-top:4px;'> 
         
    <td><input  type='text' value='".$a."'  class='textbox tt form-control' id='textbox'></td>

    <td><input  type='hidden' value='".$a."'  class='textbox1 form-control' id='textbox1'></td>

<td><input type='checkbox' name='check'  value='".$a."' class='check checkbox-primary' style='margin-left:5px;'>Add Column</td></tr></table>";
}
}
  echo "</div>

        </div>
       <input type='submit' name='submit' id='submit' value='submit' class='col-md-2 btn btn-md btn btn-primary '>

       </div>
        ";
    
 
    fclose($handle);

 // }
  
  }
  
//}

}
else{
  $show="please select a file";
 }
}

?>