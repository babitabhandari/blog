<?php 
   

 if(isset($_POST['upload'])){
if ($_FILES['csv']['size'] > 0) { 
// the table fields 

//get the csv file 
$file = $_FILES['csv']['tmp_name'];
$handle = fopen($file,"r"); 

$csv_fields = fgetcsv($handle,1000,",",'"'); 
if ($handle !== FALSE) {
 // $data = fgetcsv($handle, 1000, ",");
    
}
 // get the first line into a fields map
  
 

  // we will insert only common fields 
  
}
}
?>
<?php

if(isset($_POST['submit'])){
if ($_FILES['csv']['size'] > 0) { 
// the table fields 
$tbl_fields = array('first_name','last_name','email','gender','age'); 
//get the csv file 
$file = $_FILES['csv']['tmp_name'];
$handle = fopen($file,"r"); 
 // get the first line into a fields map
  $csv_fields = fgetcsv($handle,1000,",",'"'); 
  // we will insert only common fields 
  $tbl_fields = array_intersect($tbl_fields,$csv_fields);
   // if there's not at least one common field, don't go on 
   if(count($tbl_fields)>0) { 
   // we need the table's field names as keys (see below) 
   $tbl_fields = array_flip($tbl_fields); 
   // now let's go after the data 
   while($data = fgetcsv($handle,1000,",",'"')) { $data=array_map('addslashes',$data); 
   // apply addslashes() to all values 
   $data=array_combine($csv_fields,$data); 
   // csv fields assoc (key=>value) 
   $data=array_intersect_key($data,$tbl_fields); // discard redundant 
   $tbl_fields_str=implode("`,`",array_keys($data)); $tbl_vals_str=implode("','",array_values($data));
   $q="INSERT INTO `details` (`$tbl_fields_str`) VALUES ('$tbl_vals_str')"; 
   mysql_query($q);
}
 } 
//get the csv file 


// $table = 'demo';

// // get structure from csv and insert db
// ini_set('auto_detect_line_endings',TRUE);
// $handle = fopen($file,'r');
// // first row, structure
// if ( ($data = fgetcsv($handle) ) === FALSE ) {
//     echo "Cannot read from csv $file";die();
// }
// $fields = array();
// $field_count = 0;
// for($i=0;$i<count($data); $i++) {
//     $f = strtolower(trim($data[$i]));
//     if ($f) {
//         // normalize the field name, strip to 20 chars if too long
//         $f = substr(preg_replace ('/[^0-9a-z]/', '_', $f), 0, 20);
//         $field_count++;
//         $fields[] = $f.' VARCHAR(50)';
//     }
// }

// $sql = "CREATE TABLE $table (" . implode(', ', $fields) . ')';
// echo $sql . "<br /><br />";
// $db=mysql_query($sql);
// while ( ($data = fgetcsv($handle) ) !== FALSE ) {
//     $fields = array();
//     for($i=0;$i<$field_count; $i++) {
//         $fields[] = '\''.addslashes($data[$i]).'\'';
//     }
//     $sql2 = "Insert into $table values(" . implode(', ', $fields) . ')';
//     //echo $sql; 
//     $db=mysql_query($sql2);
// }
// fclose($handle);
// ini_set('auto_detect_line_endings',FALSE);
// $handle = fopen($file,"r"); 
//  // get the first line into a fields map
//   $csv_fields = fgetcsv($handle,1000,",",'"'); 
//   // we will insert only common fields 
//   $row = 1; 
// $columns = [];

// while (($data = fgetcsv($handle, 1000, ",")) !== FALSE AND $row==1) {
//    $columns = $data;
//    $row++; 
// }

//SQL string commands
// $createSQL = mysql_query("CREATE TABLE 'demo' IF NOT EXISTS $table 
//               (".implode(" VARCHAR(255) NOT NULL, ", $columns). " 
//                VARCHAR(255) NOT NULL);");

// $file1 = addslashes(realpath(dirname(__FILE__)).'\\'.$file1);
// $loadSQL = mysql_query("LOAD DATA INFILE '$file1' 
//             INTO TABLE $table 
//             FIELDS TERMINATED BY ',' 
//             IGNORE 1 LINES");
 }

}

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Document</title>
  <link rel="stylesheet" href="css/design.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script> 
  </head>
<body>
  <div class = "container">
  <div class="wrapper">
    <form action="" method="post" class="form-signin" enctype="multipart/form-data">       
        <h3 class="form-signin-heading">User Upload File</h3>
        <hr class="colorgraph"><br>
        <?php
        if(isset($_POST['submit'])){
global $q;
   global $show;
   if($q){
  echo '<div class="alert alert-success">csv file has been uploaded</div>';
    }
    else{
      echo '<div class="alert alert-danger">'.$show.'</div>';
    }
    }
 ?>

        <label for=""> Select A file:-</label>
        <input type="file" class="form-control" name="csv"   autofocus="" /><br>
        <input type="submit" class="btn btn-lg btn-primary btn-block"  name="upload" value="Upload" >
        <input type="submit" name="submit" id="" value="submit" class="btn btn-lg btn btn-primary btn-block">
        <br>
        <a href="" class="link">Please Search here</a><div class="srch" style="display:none;">
        <select  class="form-control"  name="age" id="age" value="<?php echo $_POST['age'];?>">
           <option value="">--select age--</option>
            <option value="20-40">between 20-40</option>
            <option value="40-60">between 40-60</option>
            <option value="60-80">between 60-80</option>
        </select>
 <script type="text/javascript">
  document.getElementById('age').value = "<?php echo $_POST['age'];?>";
</script>
<label for="">Gender</label>
    <input type="radio" class="radio-inline" name="gender" value="female" group="female" <?php if(isset($_POST['search']) == 'female') echo 'checked="checked" ';?>>female
        <input type="radio" class="radio-inline" name="gender"  value="male" group="male " <?php if(isset($_POST['search']) == 'male') echo 'checked="checked" ';?>>male
        
       <input type="submit" name="search" id="" value="search" class="btn btn-primary">

        
        </div>
        <input type="submit" name="export" style="display:none;" id="export" value="export" class="btn btn-primary">      
    </form>     
  </div>
</div>
<script>
  $(document).ready(function(){
    $('.link').on("click",function(){
$('.srch').show();
return false;
  });
  });
</script>

<!-- <div class="container" id="cont" style="display:none;background:#F5F7FA";> -->
  <!-- <div class="row">
    <div class="col-md-6">
      <h1>csv headers</h1>
      frstname
    </div>
    <div class="col-md-6">
      <h1>database headers</h1>
      first_name
    </div>
  </div> -->
<!-- </div> -->
</body>
</html>
<?php
 if(isset($_POST['search'])){

$output = "";
$gender ="";
$age="";
if(!empty($_POST['age'])) {
$age=$_POST['age'];
$var1=$age;
$var = explode("-", $var1);
$var2= $var[0]; // piece1
$var3= $var[1]; // piece2
}
if(!empty($_POST['gender'])) {
$gender=$_POST['gender'];
}
if($gender=="" && $age!=""){
$qre=mysql_query("select * from details  where age Between '$var2' AND '$var3'");
}
elseif($age=="" && $gender!=""){
$qre=mysql_query("select * from details where gender='$gender'");
}
elseif($age!="" && $gender!=""){
$qre=mysql_query("select * from details   where age Between '$var2' AND '$var3' && gender='$gender'");
}
$columns_total = mysql_num_fields($qre);
echo '<table class="table table-inverse" style="float:left;">
<tr><th>First Name</th><th>Last Name</th><th>Email</th>
<th>Gender</th><th>Age</th>';
echo '</tr>';
echo '<tr>';
while ($r = mysql_fetch_array($qre)) {
echo '<tr>';  
for ($i = 1; $i < $columns_total; $i++) {
echo '<td>'.$output =$r[$i].'</td>';
//$output .="\n";
 //echo '</br>';
}
echo '</tr>';
//$output .="\n";
}
echo '</tr>';
echo '</table>';
if($output!=""){
  echo $output;
echo '<script type="text/javascript">
 $("#export").css("display","block");
 </script>';
 exit();
}
else{
    echo "data not found";
}
}       
 ?>
<?php 
if(isset($_POST['export'])){
 $output = "";
$gender ="";
$age="";

if(!empty($_POST['age'])) {
$age=$_POST['age'];
$var1=$age;
$var = explode("-", $var1);
$var2= $var[0]; // piece1
$var3= $var[1]; // piece2
}
if(!empty($_POST['gender'])) {
$gender=$_POST['gender'];
}
//echo $gender;
// echo $age;
        
//echo $var1;
if(empty($gender) && $age!= 'null'){
$qre=mysql_query("select * from details where age Between '$var2' AND '$var3'");
}
elseif(empty($age) && $gender!= 'null'){
$qre=mysql_query("select * from details where gender='$gender'");
}
elseif($age!= 'null' && $gender!= 'null'){
$qre=mysql_query("select * from details   where age Between '$var2' AND '$var3' && gender='$gender'");
}
$columns_total = mysql_num_fields($qre);
while ($r = mysql_fetch_array($qre)) {
for ($i = 1; $i < $columns_total; $i++) {
$output .='"'.$r["$i"].'",';
}
$output .="\n";
}
$filename = "dem.csv";
header('Content-type: text/csv');
header('Content-Disposition: attachment; filename='.$filename);
ob_end_clean();
echo $output;
exit;
 }
?>
