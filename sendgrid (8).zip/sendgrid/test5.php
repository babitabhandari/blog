<?php

    if (($handle = fopen("D:/babita/wamp/www/sendgrid/uploads/details.csv", "r")) !== false) {
        
        $csv_fields = fgetcsv($handle,1000,",",'"'); 
        $num = count($csv_fields);
        $num1 = count($handle);
        //echo $num1;
        
        
        $v=0;
        $flag = true;
$count=0;

$c =0; 

// if($handle)
// { 
//     while(!feof($handle) && $c!=3)
//   {
//   $content = fgets($handle); 
//   if($content)
//   {

//  echo $content."<br>"; 
//     $c++;

//   }
//  }
// }


 


//  while($v<$num)
//         {
            
//      $handle1 = fopen("D:/babita/wamp/www/sendgrid/uploads/details.csv", "r");
//     // //for removing headers
//     fgetcsv($handle1,1000,",");
//  if($handle1){
//     while(!feof($handle1) && $c!=3){
//     while (($data = fgetcsv($handle1, 8000, ",")) !== FALSE) {
//     $content = fgets($handle1);
//     if($content)
//     {
// //   {
//        //if($flag) {  $flag = false; continue; }

//    // echo $v;
//      echo $data[$v] . "\n";
//        //echo $content;  
//      //echo $content[$c];
//      echo "<br>";
//      $c++;

// }
//      }
//      $v++;
//  }
// }
     
   
//  }
 


  while($v<$num)
        {
            
     $handle1 = fopen("D:/babita/wamp/www/sendgrid/uploads/details.csv", "r");
     //for removing headers
    fgetcsv($handle1,1000,",");
 //if($handle1){
    while(!feof($handle1) && $c!=3){
    while (($data = fgetcsv($handle1, 8000, ",")) !== FALSE) {
    $content = fgets($handle1);
    if($content)
    {

       

   // echo $v;
     echo $data[$v] . "\n";
       //echo $content;  
     //echo $content[$c];
     echo "<br>";
     $c++;

//}
     }
     $v++;
 }
//}
     
   
 }
 



}


 ?>