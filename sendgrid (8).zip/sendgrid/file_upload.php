<?php 
   require 'db.php';

 if(isset($_POST['upload'])){
if ($_FILES['csv']['size'] > 0) { 
  $ss="hii";
$show= '';
$file = $_FILES['csv']['tmp_name'];
$target_dir = "uploads/";
$target_file = $target_dir . basename($file);
// $target_file = $target_dir . basename($file);
$handle = fopen($file,"r"); 
$store=$_FILES["csv"]["name"];
 move_uploaded_file($file, "uploads/" . $store);
            //echo "Stored in: " . "uploads/" . $store . "<br />";
$csv_fields = fgetcsv($handle,1000,",",'"'); 
// echo "Upload: " . $_FILES["csv"]["name"] . "<br />";
//              echo "Type: " . $_FILES["csv"]["type"] . "<br />";
//              echo "Size: " . ($_FILES["csv"]["size"] / 1024) . " Kb<br />";
//              echo "Temp File: " . $target_dir.$_FILES["csv"]["name"] . "<br />";
$tbl_fields = array('first_name','last_name','email','gender','age');
if ($handle !== FALSE) {
 // $data = fgetcsv($handle, 1000, ",");
    if($csv_fields !== FALSE) {
        $num = count($csv_fields);
        echo '<div class="container" style="background:#F5F7FA;">
        <div class="row">
        <div class="col-md-6">';
        echo "<h3> No of Csv headers:-$num <br /></h3>\n";
       
        for ($c=0; $c < $num; $c++) {
            echo "<input type='checkbox' id='check' name='check' value='".$csv_fields[$c]."'>".$csv_fields[$c] . "<br />\n";
        }

       echo  '</div>
       <div id="selected"> </div>

       <div class="col-md-6">
       <h3>database headers</h3>';
    
$res = mysql_query("select * from details");

echo mysql_field_name($res, 1)."<br>";
echo mysql_field_name($res, 2)."<br>";
echo mysql_field_name($res, 3)."<br>";
echo mysql_field_name($res, 4)."<br>";
echo mysql_field_name($res, 5)."<br>";
echo "<br>";

       echo '</div>
        </div>
       </div>';
    }
    fclose($handle);
}
}


else{
  $show="please select a file";
 }


}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Document</title>
  <link rel="stylesheet" href="css/design.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>

  </head>
<body>
  <div class = "container">
  <div class="wrapper">
    <form action="" method="post" class="form-signin" enctype="multipart/form-data">       
        <h3 class="form-signin-heading">User Upload File</h3>
        <hr class="colorgraph"><br>
        <?php
        if(isset($_POST['submit'])){
global $q;
   global $show;
   if($q){
  echo '<div class="alert alert-success">csv file has been uploaded</div>';
    }
    else{
     echo '<div class="alert alert-danger">'.$show.'</div>';
    }
    }
 ?>

        <label for=""> Select A file:-</label>
        <input type="file" class="form-control" name="csv"   autofocus=""  id="file"/><br>
        <input type="submit" class="btn btn-lg btn-primary btn-block"  name="upload" value="Upload" >
        <input type="submit" name="submit" id="submit" value="submit" class="btn btn-lg btn btn-primary btn-block">
        <br>
        <a href="" class="link">Please Search here</a><div class="srch" style="display:none;">
        <select  class="form-control"  name="age" id="age" value="<?php echo $_POST['age'];?>">
           <option value="">--select age--</option>
            <option value="20-40">between 20-40</option>
            <option value="40-60">between 40-60</option>
            <option value="60-80">between 60-80</option>
        </select>
<label for="">Gender</label>
    <input type="radio" class="radio-inline" name="gender" value="female" group="female" <?php if(isset($_POST['search']) == 'female') echo 'checked="checked" ';?>>female
        <input type="radio" class="radio-inline" name="gender"  value="male" group="male " <?php if(isset($_POST['search']) == 'male') echo 'checked="checked" ';?>>male
        
       <input type="submit" name="search" id="" value="search" class="btn btn-primary">

        
        </div>
        
        <input type="submit" name="export" style="display:none;" id="export" value="export" class="btn btn-primary"> 
    </form>     
  </div>
</div>
<script>
  $(document).ready(function(){
    $('.link').on("click",function(){
$('.srch').show();
return false;
  });
  });
</script>
<script>

 $(document).ready(function(){
     $('#submit').click(function(){

<?php global $store; ?>
             var store= '<?php echo $store; ?>'; 
         var check = $('input[name=check]:checked').map(function()
         {
             return $(this).val();
         }).get();

         $.ajax({
             url: 'ajax.php',
             type: 'post',
             data: { check: check, store: store },
             success:function(data){
 alert(data);
             }
         });
         return false;
     });
 });

</script>
</body>
</html>
<?php
 if(isset($_POST['search'])){

$output = "";
$gender ="";
$age="";
$header='';
$data='';
if(!empty($_POST['age'])) {
$age=$_POST['age'];
$var1=$age;
$var = explode("-", $var1);
$var2= $var[0]; // piece1
$var3= $var[1]; // piece2
}
if($_POST['gender']!="") {
$gender=$_POST['gender'];
echo $gender;
}
if($gender=="" && $age==""){
  echo "<div class='alert alert-danger'>please select age or gender</div>";
}
else{
if($gender=="" && $age!=""){
 $qre=mysql_query("select * from user  where age Between '$var2' AND '$var3'");
}
if($age=="" && $gender!=""){
 // $qre=mysql_query("select * from user where gender='$gender'");
  $qre=mysql_query("select * from user where gender='$gender'");
  
 
}
if($age!="" && $gender!=""){
 $qre=mysql_query("select * from user   where (age Between '$var2' AND '$var3') AND gender='$gender'");
 }}

$columns_total = mysql_num_fields($qre);


echo '<table class="table table-inverse" style="float:left;">
<tr><th>First Name</th><th>Last Name</th><th>Email</th>
<th>Gender</th><th>Age</th>';

echo '</tr>';
echo '<tr>';
while ($r = mysql_fetch_array($qre)) {


echo '<tr>';  
for ($i = 1; $i < $columns_total; $i++) {
echo '<td>'.$output =$r[$i].'</td>';
//$output .="\n";
 //echo '</br>';
}
echo '</tr>';
//$output .="\n";
}
//$fields = mysql_num_fields($qre);



echo '</tr>';
echo '</table>';
if($output!=""){
  echo $output;
 
echo '<script type="text/javascript">
 $("#export").css("display","block");
 </script>';
 exit(); 
}
}
?>
<?php 
 if(isset($_POST['export'])){
  $data='';
  $header='';
$output = "";
$gender ="";
$age="";
if(!empty($_POST['age'])) {
$age=$_POST['age'];
$var1=$age;
$var = explode("-", $var1);
$var2= $var[0]; // piece1
$var3= $var[1]; // piece2
}
if($_POST['gender']!="") {
$gender=$_POST['gender'];
echo $gender;
}
if($gender=="" && $age==""){
  echo "<div class='alert alert-danger'>please select age or gender</div>";
}
else{
if($gender=="" && $age!=""){
 $qre=mysql_query("select * from user  where age Between '$var2' AND '$var3'");
}
if($age=="" && $gender!=""){
 // $qre=mysql_query("select * from user where gender='$gender'");
  $qre=mysql_query("select * from user where gender='$gender'");
  
 
}
if($age!="" && $gender!=""){
 $qre=mysql_query("select * from user   where (age Between '$var2' AND '$var3') AND gender='$gender'");
 }}

// $select = 'select * from user';

//$export = mysql_query ( $select ) or die ( "Sql error : " . mysql_error( ) );

$fields = mysql_num_fields($qre);

for( $i = 0; $i < $fields; $i++ )
{
    $header .= mysql_field_name( $qre , $i ) . "\t";
}

while( $row = mysql_fetch_row( $qre) )
{
    $line = '';
    foreach( $row as $value )
    {                                            
        if ( ( !isset( $value ) ) || ( $value == "" ) )
        {
            $value = "\t";
        }
        else
        {
            // $value = str_replace( '"' , '""' , $value );
            $value = "' $value '" . "\t";
        }
        $line .= $value;
    }
    $data .= trim( $line ) . "\n";
}
// $data = str_replace( "\r" , "" , $data );

if ( $data == "" )
{
    $data = "\n(0) Records Found!\n";                        
}
header("Content-type: application/octet-stream");
header("Content-Disposition: attachment; filename=babi.csv");
header("Pragma: no-cache");
header("Expires: 0");
ob_end_clean();

print "$header\n$data";

   }
 
 
?>
