<?php 
   require 'db.php';

 if(isset($_POST['upload'])){
if ($_FILES['csv']['size'] > 0) { 
  $ss="hii";
   
// $p=mysql_field_name($res,1);
// $p1=mysql_field_name($res,2);
// $p2=mysql_field_name($res,3);
//$res='';

$columnnames='';
$i=0;
$numcolumn='';
$show= '';
echo '<select>';
$res = mysql_query('select * from detail');
$numcolumn = mysql_num_fields($res);
for ( $i = 0; $i < $numcolumn; $i++ ) {
            $columnnames = mysql_field_name($res, $i);
            echo '<option value="'.$columnnames.'">'.$columnnames.'</option>';
          }
          echo '<select>';
 
$file = $_FILES['csv']['tmp_name'];
$target_dir = "uploads/";
$target_file = $target_dir . basename($file);
// $target_file = $target_dir . basename($file);
$handle = fopen($file,"r"); 

$store=$_FILES["csv"]["name"];
 move_uploaded_file($file, "uploads/" . $store);
            //echo "Stored in: " . "uploads/" . $store . "<br />";
$csv_fields = fgetcsv($handle,1000,",",'"'); 

//   if($handle !== FALSE) {
//  while(! feof($handle)) {
//   $data = fgetcsv($handle, 1024);
//   print $data[0]. "<BR>";
//  }
// }
//$data = fgetcsv($f, 8000, ",");

$row = 1;
$f = $handle;
// while (($data = fgetcsv($f, 8000, ",")) !== FALSE) {
//     $num = count($data);
//     $row++;
//     for ($v=0; $v < $num; $v++) {
//         echo $data[$v] . "\n";}}

$tbl_fields = array('first_name','last_name','email');
if ($handle !== FALSE) {
 // $data = fgetcsv($handle, 1000, ",");
    if($csv_fields !== FALSE) {
      if($csv_fields!== $tbl_fields){
        $num = count($csv_fields);
        $row = 1;

while (($data = fgetcsv($f, 8000, ",")) !== FALSE) {
    $num = count($data);
    $row++;
    for ($v=0; $v < $num; $v++) {
        echo $data[$v] . "\n";}}

        echo 'please check the  column headers';
        echo '<div class="container" style="background:#F5F7FA;">
        <div class="row">
        <div class="col-md-6">';
       
         for ($c=0; $c < $num; $c++) {
          
         echo "<select name='drop' class='drop' style='width:200px;'>
           
          <option style='border-bottom:2px solid red;' selected value='".$csv_fields[$c]."'>$csv_fields[$c]</option>
         <option value='text'>text</option>
         <option value='number'>number</option>



    <input type='checkbox' id='check' name='check' value='".$csv_fields[$c]."'>
           </select>";
         
      echo "<div class='header'>
  
  
    </div>
          <br />\n";
          
      }

       echo  '</div>
       <div id="selected"> </div>
<div class="col-md-6" id="para">
</div>
       
        </div>
       </div>';
    
    fclose($handle);
  }
  else{
   $num = count($csv_fields);
        
        echo '<div class="container" style="background:#F5F7FA;">
        <div class="row">
        <div class="col-md-6">';
       
         for ($c=0; $c < $num; $c++) {
          
         echo "<select name='drop' class='drop' style='width:200px;'>
           
          <option style='border-bottom:2px solid red;' selected value='".$csv_fields[$c]."'>$csv_fields[$c]</option>
         <option value='text'>text</option>
         <option value='number'>number</option>
         


    <input type='checkbox' id='check' name='check' value='".$csv_fields[$c]."'>
           </select>";
          echo  "<div class='header'>
           

           </div>
          <br />\n";
          
      }

       echo  '</div>
       <div id="selected"> </div>
<div class="col-md-6" id="para">
</div>
       
        </div>
       </div>';
    
    fclose($handle); 
  }
  }
}
}


else{
  $show="please select a file";
 }


}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Document</title>
  <link rel="stylesheet" href="css/design.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
  
<script>

      jQuery(function($){                      //calling the code inside braces when document loads and passing jQuery object as '$' parameter;
   $("select[name='drop']").change(function(){        //binding an event that fires every time select value changes
      var select = $(this);              //caching select, which value was changed
      if(select.val() == "text"){     //checking if we selected the right option
          $("<input>").attr({type: "text", name: "text",class: "t"}).appendTo(select.parent());   //creating new input element object, setting its value to "value4" and appending to select parent element or wherever you want it
$('.n').hide();
      }

      else{
        $("<input>").attr({type: "number", name: "number",class: "n"}).appendTo(select.parent());
        $('.t').hide(); 
      }

   });        
});
        
    </script>
  </head>
<body>
  <div class = "container">
  <div class="wrapper">
    <form action="" method="post" class="form-signin" enctype="multipart/form-data">       
        <h3 class="form-signin-heading">User Upload File</h3>
        <hr class="colorgraph"><br>
        <label for=""> Select A file:-</label>
        <input type="file" class="form-control" name="csv"   autofocus=""  id="file"/><br>
        <input type="submit" class="btn btn-lg btn-primary btn-block"  name="upload" value="Upload" >
        <input type="submit" name="submit" id="submit" value="submit" class="btn btn-lg btn btn-primary btn-block">
        <br>
        <a href="" class="link">Please Search here</a><div class="srch" style="display:none;">
        <select  class="form-control"  name="age" id="age" value="<?php echo $_POST['age'];?>">
           <option value="">--select age--</option>
            <option value="20-40">between 20-40</option>
            <option value="40-60">between 40-60</option>
            <option value="60-80">between 60-80</option>
        </select>
 
<label for="">Gender</label>
    <input type="radio" class="radio-inline" name="gender" value="female" group="female" <?php if(isset($_POST['search']) == 'female') echo 'checked="checked" ';?>>female
        <input type="radio" class="radio-inline" name="gender"  value="male" group="male " <?php if(isset($_POST['search']) == 'male') echo 'checked="checked" ';?>>male
        
       <input type="submit" name="search" id="" value="search" class="btn btn-primary">

        
        </div>
        <input type="submit" name="export" style="display:none;" id="export" value="export" class="btn btn-primary"> 
        
    </form>     
  </div>
</div>



 