<?php
$arrayToBeSorted = array('last_name','email','customer_name','gender','contact');
$order = array('customer_name','last_name','email','gender','contact');

// sort array
usort($arrayToBeSorted, function($a, $b) use ($order){
   // sort using the numeric index of the second array
   $valA = array_search($a, $order);
   $valB = array_search($b, $order);

   // move items that don't match to end
   if ($valA === false)
       return -1;
   if ($valB === false)
       return 0;

   if ($valA > $valB)
       return 1;
   if ($valA < $valB)
       return -1;
   return 0;
});
print_r($arrayToBeSorted);
$v= $arrayToBeSorted;
print_r($v);