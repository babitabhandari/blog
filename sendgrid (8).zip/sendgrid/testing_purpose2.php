<?php 
require 'db.php';
require 'custom2.php';


?>
<?php 
if(isset($_POST['export'])){

$output = "";
$gender ="";
$age="";
$header='';
$data='';
if(!empty($_POST['age'])) {
$age=$_POST['age'];
$var1=$age;
$var = explode("-", $var1);
$var2= $var[0]; // piece1
$var3= $var[1]; // piece2
}
if($_POST['gender']!="") {
$gender=$_POST['gender'];
 
}
if($gender=="" && $age==""){
  echo "<div class='alert alert-danger'>please select age or gender</div>";
}
else{
if($gender=="" && $age!=""){
 $qre=mysql_query("select * from user  where age Between '$var2' AND '$var3'");
}
if($age=="" && $gender!=""){
 // $qre=mysql_query("select * from user where gender='$gender'");
  $qre=mysql_query("select * from user where gender='$gender'");
  
 
}
if($age!="" && $gender!=""){
 $qre=mysql_query("select * from user   where (age Between '$var2' AND '$var3') AND gender='$gender'");
 }}

  
  
 header('Content-Type: text/csv; charset=utf-8');
 header('Content-Disposition: attachment; filename=babi.csv');
$data = fopen('php://output', 'w');
//$q = mysql_query('SELECT * FROM user');
while($row = mysql_fetch_assoc($qre)){
  fputcsv($data, $row);
}
exit(); 
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Document</title>
  <link rel="stylesheet" href="css/design.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
  <style>
  #t1,#t2{
  margin-top:-30px;
  margin-left:210px;
}
.drop{
  width:200px;
  float:left;
  /*outline:1px solid red;*/
  }
  .tt{
  outline:1px solid red;
}
  </style>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
  <script>
  $('.tt').click(function(){
$('.tt').css('outline','none');
  });
  </script>
  <script>
    $(function(){

    $('.btn').on('click',function() {                 
        $(this).closest('.panel').fadeOut('slide',function(){
            $('.panel').hide();    
        });
        });
})
</script>

 <script>
  jQuery(function($){  
   $(".select_drop").on('change', function(){
     var $this = $(this),
         selectedType = $this.val();
     if($this.closest('tr').find('.dynamic_text').length == 0) $(this).closest('tr').append("<table><tr><td><form method='post'><input type='text' class='dynamic_text'></form></td></tr></table>")
     //if($this.closest('tr').find('.dynamic_text').length == 0) $(this).closest('tr').append("<form method='post'><td><input type='text' class='dynamic_text'></td></form>")
    });
$('.drop').on('change', function(){
    var $selectBox = $(this);
    $(this).find("[label='database headers']").find('option').each(function(){
      if($selectBox.val() == $(this).val()) $selectBox.parent().next().find('.textbox').hide();
    })
     })
  });
  </script>

       <script>
  $(document).ready(function(){
    $('.link').on("click",function(){
$('.srch').show();
    return false;

  });
    
  });
</script>

<script>
$(document).ready(function(){
$('#submit').click(function(){
  <?php global $store; ?>
             var store= '<?php echo $store; ?>'; 
 var textbox = [];
   var textbox1 = [];
   var textbox2= [];
    var check = [];
    //var dynamic_text= $('.dynamic_text').val();
var dynamic_text= [];
   // alert(dynamic_text);
   $('.check').each(function() {
 if ($(this).is(':checked')) {
               var current = $(this).val();

              //alert(current);
             textbox.push($(this).parents("tr").find(".textbox").val())
             textbox1.push($(this).parents("tr").find(".textbox1").val())
             textbox2.push($(this).parents("tr").find(".textbox2").val())
            dynamic_text.push($(this).parents("tr").find(".dynamic_text").val())

         }
  check.push($(this).val());
});

               $.ajax({
             url: 'aj2.php',
             type: 'post',
             data: { check: textbox, store: store, oldval: textbox1, olddropval:textbox2,dynamic_text:dynamic_text},
             success:function(data){
              alert(data);
 //alert("Data save!!!");
             }
         });
return false;
});
});
</script>

    </head>
<body>
  <div class = "container">
  <div class="wrapper">
    <form action="" method="post" class="form-signin" enctype="multipart/form-data">       
        <h3 class="form-signin-heading">User Upload File</h3>
        <hr class="colorgraph"><br>
        <?php
//         if(isset($_POST['upload'])){
// global $q;
//    global $show;
//    if($q){
//   echo '<div class="alert alert-success">csv file has been uploaded</div>';
//     }
//     else{
//      echo '<div class="alert alert-danger">'.$show.'</div>';
//     }
//     }
 ?>
        <label for=""> Select A file:-</label>
        <input type="file" class="form-control" name="csv"   autofocus=""  id="file"/><br>
        <input type="submit" class="btn btn-lg btn-primary btn-block"  name="upload" value="Upload" >
        <!-- <input type="submit" name="submit" id="submit" value="submit" class="btn btn-lg btn btn-primary btn-block">
         -->
         <br>
    <a href="" class="link">Please Search here</a><div class="srch" style="display:none;">
        <select  class="form-control"  name="age" id="age" value="<?php echo $_POST['age'];?>">
           <option value="">--select age--</option>
            <option value="20-40">between 20-40</option>
            <option value="40-60">between 40-60</option>
            <option value="60-80">between 60-80</option>
        </select>
        </select>
 <script type="text/javascript">
  document.getElementById('age').value = "<?php echo $_POST['age'];?>";
</script>
<label for="">Gender</label>
    <input type="radio" class="radio-inline" name="gender" value="female"<?php if (isset($_POST['gender']) && $_POST['gender'] == 'female') echo ' checked="checked"';?>group="female">female
    
   
        <input type="radio" class="radio-inline" name="gender"  value="male"<?php if (isset($_POST['gender']) && $_POST['gender'] == 'male') echo ' checked="checked"'; ?> group="male">male
       
       <input type="submit" name="search" id="" value="search" class="btn btn-primary">
 </div>
        <input type="submit" name="export" style="display:none;" id="export" value="export" class="btn btn-primary"> 
      </form>     
  </div>
</div>
 </body>
</html>
<?php
if(isset($_POST['search'])){
$output = "";
$gender ="";
$age="";
$header='';
$data='';
if(!empty($_POST['age'])) {
$age=$_POST['age'];
$var1=$age;
$var = explode("-", $var1);
$var2= $var[0]; // piece1
$var3= $var[1]; // piece2
}

if($_POST['gender']!="") {
$gender=$_POST['gender'];

echo $gender;

}
if($gender=="" && $age==""){
  echo "<div class='alert alert-danger'>please select age or gender</div>";
}
else{
if($gender=="" && $age!=""){
 $qre=mysql_query("select * from user  where age Between '$var2' AND '$var3'");
}
if($age=="" && $gender!=""){
 // $qre=mysql_query("select * from user where gender='$gender'");
  $qre=mysql_query("select * from user where gender='$gender'");
  
 
}
if($age!="" && $gender!=""){
 $qre=mysql_query("select * from user   where (age Between '$var2' AND '$var3') AND gender='$gender'");
 }}


echo '<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>';
  echo '<script type="text/javascript">
 $("#export").css("display","block");

  </script>';
$columns_total = mysql_num_fields($qre);
echo '<table class="table table-inverse" style="float:left;">
<tr><th>First Name</th><th>Last Name</th><th>Email</th>
<th>Gender</th><th>Age</th>';
echo '</tr>
<tr>';
while ($r = mysql_fetch_array($qre)) {
echo '<tr>';  
for ($i = 1; $i<$columns_total; $i++) {
echo '<td>'.$output =$r[$i].'</td>';
}
echo '</tr>';
}
//$fields = mysql_num_fields($qre);
echo '</tr>';
echo '</table>';
}
?>
