<?php 

   require 'db.php';

 if(isset($_POST['upload'])){
if ($_FILES['csv']['size'] > 0) { 
  
   
$columnnames='';
$i=0;
$numcolumn='';
$show= '';
$numcolumn1='';
 $columnnames1='';
$j=0;

$file = $_FILES['csv']['tmp_name'];
$target_dir = "uploads/";
$target_file = $target_dir . basename($file);
// $target_file = $target_dir . basename($file);
$handle = fopen($file,"r"); 

$store=$_FILES["csv"]["name"];
 move_uploaded_file($file, "uploads/" . $store);
            //echo "Stored in: " . "uploads/" . $store . "<br />";
$csv_fields = fgetcsv($handle,1000,",",'"'); 

//$tbl_fields = array('first_name','last_name','email');
//$tbl_fields = array('first_name','last_name','email');
$arr12=array();

$sql = "SHOW COLUMNS FROM detail";
 $result = mysql_query($sql);

while($row = mysql_fetch_assoc($result)){
$arr12[]=$row['Field'];
}
//print_r($arr);
$tbl_fields=array_slice($arr12, 1);
$array1 = $csv_fields;
$array2 = $tbl_fields; 
//print_r($array2);
$words1 =  array_unique($array1);
//print_r($words1)."<br>";

$words2 =  array_unique($array2);
//print_r($words2)."<br>";
$default=array();
$intersection = array_intersect($words1, $words2);


if(count($array1)<=count($array2))
$intersection1 = array_diff($words2, $words1);
else
$intersection1 = array_diff($words1, $words2);
// 1 me hai pr two me nhi h   

//print_r($intersection1);

//print_r($tbl_fields);
$row = 1;
$f = $handle;


//$tbl_fields = array('first_name','last_name','email');
if ($handle !== FALSE) {

  //if($csv_fields !== FALSE) {
   echo "Please check the column headers below to confirm we've labeled them correctly.";
      echo  "<div class='container-fluid'>
<div class='row'>
        <div class='col-sm-4 col-md-8 sidebar'>
    <div class='mini-submenu'>
        <span class='icon-bar'></span>
        <span class='icon-bar'></span>
        <span class='icon-bar'></span>
    </div>";

foreach($intersection as $a)
{
       echo ""; 
echo "<div class='list-group' style='display:none;'>
        <span href='#'' class='list-group-item active'>
        file upload contetn
        <span class='pull-right' id='slide-submenu'>
                <span class='glyphicon glyphicon-remove'></span>
            </span>
            </span></span>
    <div class='form-group'><table><tr><td>
<select name='drop' class='textbox textbox1 form-control' style='width:200px;'>"; 
          
         echo "<option  value='".$a."'>$a</option>";
       
         echo "<optgroup label='newtextfields' class='txtfields' >
         <option value='text' >text</option>
         <option value='number'>number</option>
         </optgroup>
         <optgroup label='database headers'>"; 
        
         $res = mysql_query('select * from detail');
$numcolumn = mysql_num_fields($res);
for ( $i = 1; $i < $numcolumn; $i++ ) {
            $columnnames = mysql_field_name($res, $i);
            echo '<option value="'.$columnnames.'" class="d">'.$columnnames.'</option>';
               
   
          } 
         echo "</optgroup></td>";

echo "<td><input type='checkbox'  name='check' value='".$a."' class='check checkbox-primary' style='margin-left:5px;'></td> 
<br>"; 

 echo "</select></tr></table></div></div> </div>        
</div>
    </div>
</div>
</div>";
   
 }
          foreach($intersection1 as $arr)
{
  echo "<div class='form-group'><select name='drop' class='drop form-control' style='width:200px;float:left;'>"; 
      
         
           echo "<optgroup selected label='newtextfields'>
         <option value='text'>text</option>
         <option value='number'>number</option>
         </optgroup>
         <optgroup label='database headers'>"; 
        
         $res = mysql_query('select * from detail');
$numcolumn = mysql_num_fields($res);
for ( $i = 1; $i < $numcolumn; $i++ ) {

            $columnnames = mysql_field_name($res, $i);
            echo '<option value="'.$columnnames.'">'.$columnnames.'</option>';
          
          } 
         echo "</optgroup>";
         echo "</select></div>";
         
        
         echo "<table style='margin-top:4px;'>
      <tr style='margin-left:10px;display:inline;margin-top:4px;'> 
         
    <td><input type='text' value='".$arr."'  class='textbox form-control' id='textbox'></td>
    <td><input type='hidden' value='".$arr."'  class='textbox1 form-control' id='textbox1'></td>

<td><input type='checkbox' name='check'  value='".$arr."' class='check checkbox-primary' style='margin-left:5px;'></td></tr></table>";

$default= $arr;
//print_r($default);  

}
          
     
         echo "</div>

       
        </div>
       </div>";
    
 
    fclose($handle);

 // }
  
  }
  
//}

}
}

?>
<head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
  
  <style>
    padding: 9px;  
  /*position: relative;*/
  width: 42px;

}

.mini-submenu:hover{
  cursor: pointer;
}

.mini-submenu .icon-bar {
  border-radius: 1px;
  display: block;
  height: 2px;
  width: 22px;
  margin-top: 5px;
}

.mini-submenu .icon-bar {
  background-color: #000;
}

#slide-submenu{
  background: rgba(0, 0, 0, 0.45);
  display: inline-block;
  padding: 0 8px;
  border-radius: 4px;
  cursor: pointer;
}
.mini-submenu{
    /*margin-top:30%;*/
}
.list-group{
   /*margin-top:-16px; */
}
    </style>
<script>
    $(function(){

    $('#slide-submenu').on('click',function() {                 
        $(this).closest('.list-group').fadeOut('slide',function(){
            $('.mini-submenu').fadeIn();    
        });
        
      });

    $('.mini-submenu').on('click',function(){       
        $(this).next('.list-group').toggle('slide');
        $('.mini-submenu').hide();
    })
})

</script>
</head>
<div class="container-fluid">
<div class="row">
		<div class="col-sm-4 col-md-8 sidebar">
    <div class="mini-submenu">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
    </div>
    <div class="list-group" style="display:none;">
        <span href="#" class="list-group-item active">
            Submenu
            <span class="pull-right" id="slide-submenu">
                <span class="glyphicon glyphicon-remove"></span>
            </span>
        </span>
        <a href="#" class="list-group-item">
            <i class="fa fa-comment-o"></i> Lorem ipsum
        </a>
           </div>        
</div>
	</div>
</div>
</div>