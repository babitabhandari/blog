<?php 

if(isset($_POST['export'])){
 $output = "";
$gender ="";
$age="";

if(!empty($_POST['age'])) {
$age=$_POST['age'];
$var1=$age;
$var = explode("-", $var1);
$var2= $var[0]; // piece1
$var3= $var[1]; // piece2
}
if(!empty($_POST['gender'])) {
$gender=$_POST['gender'];
}
//echo $gender;
// echo $age;
        
//echo $var1;
if(empty($gender) && $age!= 'null'){
$qre=mysql_query("select * from detail where age Between '$var2' AND '$var3'");
}
elseif(empty($age) && $gender!= 'null'){
$qre=mysql_query("select * from detail where gender='$gender'");
}
elseif($age!= 'null' && $gender!= 'null'){
$qre=mysql_query("select * from detail   where age Between '$var2' AND '$var3' && gender='$gender'");
}
$columns_total = mysql_num_fields($qre);
while ($r = mysql_fetch_array($qre)) {
for ($i = 1; $i < $columns_total; $i++) {
$output .='"'.$r["$i"].'",';
}
$output .="\n";
}
$filename = "demo.csv";
header('Content-type: text/csv');
header('Content-Disposition: attachment; filename='.$filename);
ob_end_clean();
echo $output;
exit;
 }
 ?>