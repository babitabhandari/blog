<?php 
   require 'db.php';

 if(isset($_POST['upload'])){
if ($_FILES['csv']['size'] > 0) { 
  $ss="hii";
   
$columnnames='';
$i=0;
$numcolumn='';
$show= '';
$numcolumn1='';
 $columnnames1='';
$j=0;

$file = $_FILES['csv']['tmp_name'];
$target_dir = "uploads/";
$target_file = $target_dir . basename($file);
// $target_file = $target_dir . basename($file);
$handle = fopen($file,"r"); 

$store=$_FILES["csv"]["name"];
 move_uploaded_file($file, "uploads/" . $store);
            //echo "Stored in: " . "uploads/" . $store . "<br />";
$csv_fields = fgetcsv($handle,1000,",",'"'); 
$tbl_fields = array('first_name','last_name','email');
$array1 = $csv_fields;
$array2 = $tbl_fields; 
//print_r($array2);
$words1 =  array_unique($array1);
print_r($words1)."<br>";

$words2 =  array_unique($array2);
print_r($words2)."<br>";

$intersection = array_intersect($words1, $words2);


if(count($array1)<=count($array2))
$intersection1 = array_diff($words2, $words1);
else
$intersection1 = array_diff($words1, $words2);
// 1 me hai pr two me nhi h   

//print_r($intersection1);


if(count($intersection))
{
  echo "<select></select>";
    echo "there is a match!";
    print_r($intersection);


}
foreach($intersection1 as $arr)
{
    echo $arr;
    echo '<input type="text">';
}
//print_r($tbl_fields);
$row = 1;
$f = $handle;
// while (($data = fgetcsv($f, 8000, ",")) !== FALSE) {
//     $num = count($data);
//     $row++;
//     for ($v=0; $v < $num; $v++) {
//         echo $data[$v] . "\n";}}

$tbl_fields = array('first_name','last_name','email');
if ($handle !== FALSE) {
 // $data = fgetcsv($handle, 1000, ",");
    // if($csv_fields !== FALSE) {
      
    //     $num = count($csv_fields);
       
        // echo 'please check the  column headers';
   if(count($intersection))
 {
        echo '<div class="container" style="background:#F5F7FA;">
        <div class="row">
        <div class="col-md-6">';
        //echo "<select name='drop' class='drop' style='width:200px;'>";
        
   // echo "there is a match!";

     $res1 = mysql_query('select * from detail');
$numcolumn1 = mysql_num_fields($res1);
       for ( $j = 1; $j < $numcolumn1; $j++ ) {

       echo "<select name='drop' class='drop' style='width:200px;'>"; 
           $columnnames1 = mysql_field_name($res1, $j); 
           echo $columnnames1;
         echo "<option  value='".$columnnames1."'>$columnnames1</option>";
        
         
           echo "<optgroup label='newtextfields'>
         <option value='text'>text</option>
         <option value='number'>number</option>
         </optgroup>
         <optgroup label='database headers'>"; 
        
         $res = mysql_query('select * from detail');
$numcolumn = mysql_num_fields($res);
for ( $i = 1; $i < $numcolumn; $i++ ) {
            $columnnames = mysql_field_name($res, $i);
            echo '<option value="'.$columnnames.'">'.$columnnames.'</option>';
          
          } 
         echo "</optgroup>
<input type='checkbox' id='check' name='check' value='".$csv_fields[$c]."'>"; 

       
          
          // echo "hi";
         echo  "<div class='header'>";
      while (($data = fgetcsv($f, 8000, ",")) !== FALSE) {
        
        //$row=1;
     $num = count($data);
     
      $line = fgets($f);
     
    echo $line;     
     for ($v=0; $v < $num; $v++) {
        //echo $data[$v]."<br>";
     }
    // $row++;
        }

     echo "</div>
         
        <br />\n";
          }
         echo "</select>"; 
       
         echo "</div>

        
  
      
     <div id='selected'> </div>
<div class='col-md-6' id='para'>
</div>
       
        </div>
       </div>";
    
 
    fclose($handle);

 // }
  
  }
  
}
}

}

// else{
//   $show="please select a file";
//  }



?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Document</title>
  <link rel="stylesheet" href="css/design.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
  
<script>

      jQuery(function($){                      
   $("select[name='drop']").change(function(){        
      var select = $(this);              
      if(select.val() == "text"){     
          $("<input>").attr({type: "text", name: "text",class: "t"}).appendTo(select.parent());   
$('.n').hide();
      }

      else{
        $("<input>").attr({type: "number", name: "number",class: "n"}).appendTo(select.parent());
        $('.t').hide(); 
      }

   });        
});
        
    </script>
  </head>
<body>
  <div class = "container">
  <div class="wrapper">
    <form action="" method="post" class="form-signin" enctype="multipart/form-data">       
        <h3 class="form-signin-heading">User Upload File</h3>
        <hr class="colorgraph"><br>
        <?php
        if(isset($_POST['submit'])){
global $q;
   global $show;
   if($q){
  echo '<div class="alert alert-success">csv file has been uploaded</div>';
    }
    else{
     echo '<div class="alert alert-danger">'.$show.'</div>';
    }
    }
 ?>

        <label for=""> Select A file:-</label>
        <input type="file" class="form-control" name="csv"   autofocus=""  id="file"/><br>
        <input type="submit" class="btn btn-lg btn-primary btn-block"  name="upload" value="Upload" >
        <input type="submit" name="submit" id="submit" value="submit" class="btn btn-lg btn btn-primary btn-block">
        <br>
        <a href="" class="link">Please Search here</a><div class="srch" style="display:none;">
        <select  class="form-control"  name="age" id="age" value="<?php echo $_POST['age'];?>">
           <option value="">--select age--</option>
            <option value="20-40">between 20-40</option>
            <option value="40-60">between 40-60</option>
            <option value="60-80">between 60-80</option>
        </select>
 <script type="text/javascript">
  document.getElementById('age').value = "<?php echo $_POST['age'];?>";
</script>
<label for="">Gender</label>
    <input type="radio" class="radio-inline" name="gender" value="female" group="female" <?php if(isset($_POST['search']) == 'female') echo 'checked="checked" ';?>>female
        <input type="radio" class="radio-inline" name="gender"  value="male" group="male " <?php if(isset($_POST['search']) == 'male') echo 'checked="checked" ';?>>male
        
       <input type="submit" name="search" id="" value="search" class="btn btn-primary">

        
        </div>
        <input type="submit" name="export" style="display:none;" id="export" value="export" class="btn btn-primary"> 
        
    </form>     
  </div>
</div>
<script>
  $(document).ready(function(){
    $('.link').on("click",function(){
$('.srch').show();
return false;
  });
  });
</script>

 <script>

 $(document).ready(function(){
     $('#submit').click(function(){

<?php global $store; ?>
             var store= '<?php echo $store; ?>'; 
         var check = $('input[name=check]:checked').map(function()
         {
             return $(this).val();
         }).get();

         $.ajax({
             url: 'ajax.php',
             type: 'post',
             data: { check: check, store: store },
             success:function(data){
 alert(data);
             }
         });
         return false;
     });
 });

</script>
</body>
</html>
<?php
 if(isset($_POST['search'])){

$output = "";
$gender ="";
$age="";
if(!empty($_POST['age'])) {
$age=$_POST['age'];
$var1=$age;
$var = explode("-", $var1);
$var2= $var[0]; // piece1
$var3= $var[1]; // piece2
}
if(!empty($_POST['gender'])) {
$gender=$_POST['gender'];
}
if($gender=="" && $age==""){
  echo "<div class='alert alert-danger'>please select age or gender</div>";
}
else{
if($gender=="" && $age!=""){
$qre=mysql_query("select * from details  where age Between '$var2' AND '$var3'");
}
elseif($age=="" && $gender!=""){
$qre=mysql_query("select * from details where gender='$gender'");
}
elseif($age!="" && $gender!=""){
$qre=mysql_query("select * from details   where age Between '$var2' AND '$var3' && gender='$gender'");
}
$columns_total = mysql_num_fields($qre);
echo '<table class="table table-inverse" style="float:left;">
<tr><th>First Name</th><th>Last Name</th><th>Email</th>
<th>Gender</th><th>Age</th>';
echo '</tr>';
echo '<tr>';
while ($r = mysql_fetch_array($qre)) {
echo '<tr>';  
for ($i = 1; $i < $columns_total; $i++) {
echo '<td>'.$output =$r[$i].'</td>';
//$output .="\n";
 //echo '</br>';
}
echo '</tr>';
//$output .="\n";
}
}
echo '</tr>';
echo '</table>';
if($output!=""){
  echo $output;
echo '<script type="text/javascript">
 $("#export").css("display","block");
 </script>';
 exit();
}
else{
    echo "data not found";
}

}

     
 ?>
<?php 
if(isset($_POST['export'])){
 $output = "";
$gender ="";
$age="";

if(!empty($_POST['age'])) {
$age=$_POST['age'];
$var1=$age;
$var = explode("-", $var1);
$var2= $var[0]; // piece1
$var3= $var[1]; // piece2
}
if(!empty($_POST['gender'])) {
$gender=$_POST['gender'];
}
//echo $gender;
// echo $age;
        
//echo $var1;
if(empty($gender) && $age!= 'null'){
$qre=mysql_query("select * from details where age Between '$var2' AND '$var3'");
}
elseif(empty($age) && $gender!= 'null'){
$qre=mysql_query("select * from details where gender='$gender'");
}
elseif($age!= 'null' && $gender!= 'null'){
$qre=mysql_query("select * from details   where age Between '$var2' AND '$var3' && gender='$gender'");
}
$columns_total = mysql_num_fields($qre);
while ($r = mysql_fetch_array($qre)) {
for ($i = 1; $i < $columns_total; $i++) {
$output .='"'.$r["$i"].'",';
}
$output .="\n";
}
$filename = "dem.csv";
header('Content-type: text/csv');
header('Content-Disposition: attachment; filename='.$filename);
ob_end_clean();
echo $output;
exit;
 }
?>
