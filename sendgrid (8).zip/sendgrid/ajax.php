<?php require 'db1.php';
   $check = $_POST['check'];
   print_r($check);
   $store= $_POST['store'];
  
 $tbl_fields = array('first_name','last_name','email','gender','age'); 

  $handle = fopen("D:/babita/wamp/www/sendgrid/uploads/".$store,"r"); 
   $check12 = fgetcsv($handle,1000,",",'"'); 
    //print_r($check12);
   $tbl_fields = array_intersect($check12,$check);
    
$arr= array_keys($tbl_fields);
$array1=array();


//print "<table>\n";
while($csv_line = fgetcsv($handle,1024)) {
   // print '<tr>';
 // print '<td>';
    for ($i = 0, $j = count($csv_line); $i < $j; $i++) {
    if(in_array($i, $arr))
    {
        $array1[]= $csv_line[$i];
        
}
 
}
$matstring=implode("','",$array1);
$matstring="'".$matstring."'";


// print_r($matstring);
$f=implode(',', $tbl_fields);

 $q="INSERT INTO `details` ($f) VALUES ($matstring)";
 // $q="INSERT INTO `details`(".mysql_real_escape_string(implode(',', $tbl_fields)).") VALUES ($matstring)";
     //echo $q;

  mysqli_query($link,$q);
   unset($array1);

//print "</td>\n";
    //print "</tr>\n";
}
if($q){
    echo  "data inserted";
  }
//print '</table>';


   




  
?>