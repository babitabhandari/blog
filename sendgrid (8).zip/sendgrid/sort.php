<?php
$data = array("email","cn","gender","age");

$sortingArr = array("cn","email","gender","age");

$result = array(); // result array
foreach($sortingArr as $val){ // loop
   $result[array_search($val, $data)] = $val; // adding values
}
print_r($result); // print results

?>